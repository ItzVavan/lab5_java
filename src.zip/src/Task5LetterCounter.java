import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class Task5LetterCounter {
    public static int countUniqueRussianLetters(String filename) throws IOException {
        Set<Character> uniqueLetters = new HashSet<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            int ch;
            while ((ch = reader.read()) != -1) {
                char c = Character.toLowerCase((char) ch);
                if ((c >= 'а' && c <= 'я') || c == 'ё') {
                    uniqueLetters.add(c);
                }
            }
        }

        return uniqueLetters.size();
    }
}