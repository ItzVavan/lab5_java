public class MeowCounterDecorator implements Meowable {
    private final Meowable target;
    private int count = 0;

    public MeowCounterDecorator(Meowable target) {
        if (target == null) {
            throw new IllegalArgumentException("Целевой объект не может быть null.");
        }
        this.target = target;
    }

    @Override
    public void meow() {
        target.meow();
        count++;
    }

    public int getCount() {
        return count;
    }

    @Override
    public String toString() {
        return target.toString() + " (мяукал " + count + " раз)";
    }
}