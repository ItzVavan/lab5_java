import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        prepareSampleFiles();
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                System.out.println("\n==========================================");
                System.out.println("  ЛАБОРАТОРНАЯ РАБОТА №5 (ВАРИАНТ 1)");
                System.out.println("==========================================");
                System.out.println("1. Задание 1 (Дробь и кэширование)");
                System.out.println("2. Задание 2 (Кот и подсчет мяуканий)");
                System.out.println("3. Задание 3 (Слияние двух списков)");
                System.out.println("4. Задание 4 (Школьное многоборье из файла)");
                System.out.println("5. Задание 5 (Количество разных букв из файла)");
                System.out.println("6. Задание 6 (Построение очереди-зеркала)");
                System.out.println("7. Задание 7.1 (Стрим точек в Polyline)");
                System.out.println("8. Задание 7.2 (Стрим парсинга и группировки)");
                System.out.println("0. Выход");
                System.out.print("Выберите пункт меню: ");

                String choice = scanner.nextLine().trim();
                System.out.println("------------------------------------------");

                try {
                    switch (choice) {
                        case "1": {
                            System.out.println("--- Задание 1: Дробь и кэширование ---");
                            CachedFraction f = new CachedFraction(1, 2);
                            System.out.println("Создана дробь: " + f);
                            System.out.println("Вызов getDoubleValue(): " + f.getDoubleValue());
                            System.out.println("Повторный вызов getDoubleValue(): " + f.getDoubleValue());
                            System.out.println("Меняем числитель на 3...");
                            f.setNumerator(3);
                            System.out.println("Вызов getDoubleValue() после изменения: " + f.getDoubleValue());
                            break;
                        }
                        case "2": {
                            System.out.println("--- Задание 2: Подсчет мяуканий ---");
                            Cat cat = new Cat("Барсик");
                            MeowCounterDecorator counter = new MeowCounterDecorator(cat);

                            System.out.println("Отправляем кота в Funs.meowsCare (мяукнет 3 раза):");
                            Funs.meowsCare(counter, counter, counter);

                            System.out.println("Результат: кот мяукал " + counter.getCount() + " раз(а).");
                            break;
                        }
                        case "3": {
                            System.out.println("--- Задание 3: Вставка L2 в L1 с сохранением порядка ---");
                            List<Integer> l1 = List.of(1, 4, 7, 10);
                            List<Integer> l2 = List.of(2, 3, 7, 8, 12);
                            System.out.println("L1: " + l1);
                            System.out.println("L2: " + l2);
                            List<Integer> merged = Task3ListMerger.mergeSorted(l1, l2);
                            System.out.println("Результат слияния: " + merged);
                            break;
                        }
                        case "4": {
                            System.out.println("--- Задание 4: Топ многоборья из файла task4_input.txt ---");
                            List<Athlete> top = Task4Processor.findTopAthletes("task4_input.txt");
                            System.out.println("Лучшие участники:");
                            for (Athlete a : top) {
                                System.out.println(a.getFullName() + " (Сумма: " + a.getTotalScore() + ")");
                            }
                            break;
                        }
                        case "5": {
                            System.out.println("--- Задание 5: Уникальные буквы в task5_input.txt ---");
                            int count = Task5LetterCounter.countUniqueRussianLetters("task5_input.txt");
                            System.out.println("Количество различных русских букв в тексте: " + count);
                            break;
                        }
                        case "6": {
                            System.out.println("--- Задание 6: Очередь [1, 2, 3] -> [1, 2, 3, 3, 2, 1] ---");
                            List<Integer> input = List.of(1, 2, 3);
                            Queue<Integer> queue = Task6QueueBuilder.buildMirroredQueue(input);
                            System.out.println("Исходный список: " + input);
                            System.out.println("Полученная очередь: " + queue);
                            break;
                        }
                        case "7": {
                            System.out.println("--- Задание 7.1: Обработка точек стримом ---");
                            List<Point> points = List.of(
                                    new Point(5, -3),
                                    new Point(2, 4),
                                    new Point(2, 4),   // дубликат
                                    new Point(1, -10),
                                    new Point(4, 2)
                            );
                            System.out.println("Исходные точки: " + points);
                            Polyline polyline = Task7StreamOps.processPointsToPolyline(points);
                            System.out.println("Результат: " + polyline);
                            break;
                        }
                        case "8": {
                            System.out.println("--- Задание 7.2: Группировка людей из task7_input.txt ---");
                            Map<Integer, List<String>> grouped = Task7StreamOps.groupPeopleByNumber("task7_input.txt");
                            System.out.println("Результат группировки:");
                            System.out.println(grouped);
                            break;
                        }
                        case "0":
                            System.out.println("Выход из программы.");
                            return;
                        default:
                            System.out.println("Ошибка: выбран неверный пункт.");
                    }
                } catch (Exception e) {
                    System.out.println("Произошла ошибка при выполнении: " + e.getMessage());
                }
            }
        }
    }
}