import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        prepareSampleFiles();
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                System.out.println("\n==========================================");
                System.out.println("  ЛАБОРАТОРНАЯ РАБОТА №5 (ВАРИАНТ 1)");
                System.out.println("==========================================");
                System.out.println("1. Задание 1 (Дробь и кэширование)");
                System.out.println("2. Задание 2 (Кот и подсчет мяуканий)");
                System.out.println("3. Задание 3 (Вставка списка L2 в L1)");
                System.out.println("4. Задание 4 (Школьное многоборье из файла)");
                System.out.println("5. Задание 5 (Количество разных букв из файла)");
                System.out.println("6. Задание 6 (Построение очереди-зеркала)");
                System.out.println("7. Задание 7.1 (Стрим точек в Polyline + Line)");
                System.out.println("8. Задание 7.2 (Стрим парсинга и группировки)");
                System.out.println("0. Выход");
                System.out.print("Выберите пункт меню: ");

                String choice = scanner.nextLine().trim();
                System.out.println("------------------------------------------");

                try {
                    switch (choice) {
                        case "1": {
                            System.out.println("--- Задание 1: Дробь и кэширование ---");
                            int num = readInt(scanner, "Введите числитель: ");
                            int den = readInt(scanner, "Введите знаменатель (не 0): ");

                            CachedFraction f = new CachedFraction(num, den);
                            System.out.println("Создана дробь: " + f);
                            System.out.println("Вызов getDoubleValue(): " + f.getDoubleValue());
                            System.out.println("Повторный вызов getDoubleValue(): " + f.getDoubleValue());

                            int newNum = readInt(scanner, "Введите новый числитель: ");
                            f.setNumerator(newNum);
                            System.out.println("Обновленная дробь: " + f);
                            System.out.println("Вызов getDoubleValue() после изменения: " + f.getDoubleValue());
                            break;
                        }
                        case "2": {
                            System.out.println("--- Задание 2: Подсчет мяуканий ---");
                            System.out.print("Введите имя кота: ");
                            String name = scanner.nextLine();
                            Cat cat = new Cat(name);
                            MeowCounterDecorator counter = new MeowCounterDecorator(cat);

                            System.out.println("Отправляем кота в Funs.meowsCare (мяукнет 3 раза):");
                            Funs.meowsCare(counter, counter, counter);

                            System.out.println("Результат: кот мяукал " + counter.getCount() + " раз(а).");
                            break;
                        }
                        case "3": {
                            System.out.println("--- Задание 3: Вставка L2 в L1 с сохранением порядка ---");
                            List<Integer> l1 = new ArrayList<>(List.of(1, 4, 7, 10));
                            List<Integer> l2 = List.of(2, 3, 7, 8, 12);
                            System.out.println("L1 до вставки: " + l1);
                            System.out.println("L2: " + l2);
                            Task3ListMerger.insertIntoSorted(l1, l2);
                            System.out.println("L1 после вставки: " + l1);
                            break;
                        }
                        case "4": {
                            System.out.println("--- Задание 4: Топ многоборья из файла task4_input.txt ---");
                            List<Athlete> top = Task4Processor.findTopAthletes("task4_input.txt");
                            System.out.println("Лучшие участники:");
                            for (Athlete a : top) {
                                System.out.println(a.getFullName() + " (Сумма: " + a.getTotalScore() + ")");
                            }
                            break;
                        }
                        case "5": {
                            System.out.println("--- Задание 5: Уникальные буквы в task5_input.txt ---");
                            int count = Task5LetterCounter.countUniqueRussianLetters("task5_input.txt");
                            System.out.println("Количество различных русских букв в тексте: " + count);
                            break;
                        }
                        case "6": {
                            System.out.println("--- Задание 6: Очередь [1, 2, 3] -> [1, 2, 3, 3, 2, 1] ---");
                            List<Integer> input = List.of(1, 2, 3);
                            Queue<Integer> queue = Task6QueueBuilder.buildMirroredQueue(input);
                            System.out.println("Исходный список: " + input);
                            System.out.println("Полученная очередь: " + queue);
                            break;
                        }
                        case "7": {
                            System.out.println("--- Задание 7.1: Обработка точек стримом ---");
                            List<Point> points = List.of(
                                    new Point(5, -3),
                                    new Point(2, 4),
                                    new Point(2, -4),  // после abs(Y) станет дубликатом (2;4)
                                    new Point(1, -10),
                                    new Point(4, 2)
                            );
                            System.out.println("Исходные точки: " + points);
                            Polyline polyline = Task7StreamOps.processPointsToPolyline(points);
                            System.out.println("Результат (Polyline): " + polyline);

                            Line sampleLine = new Line(points.get(0), points.get(1));
                            System.out.println("Демонстрация класса Line: " + sampleLine);
                            break;
                        }
                        case "8": {
                            System.out.println("--- Задание 7.2: Группировка людей из task7_input.txt ---");
                            Map<Integer, List<String>> grouped = Task7StreamOps.groupPeopleByNumber("task7_input.txt");
                            System.out.println("Результат группировки:");
                            System.out.println(grouped);
                            break;
                        }
                        case "0":
                            System.out.println("Выход из программы.");
                            return;
                        default:
                            System.out.println("Ошибка: выбран неверный пункт.");
                    }
                } catch (Exception e) {
                    System.out.println("Ошибка выполнения: " + e.getMessage());
                }
            }
        }
    }

    private static int readInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Ошибка: введите корректное целое число.");
            }
        }
    }

    private static void prepareSampleFiles() {
        try {
            if (!Files.exists(Path.of("task4_input.txt"))) {
                Files.writeString(Path.of("task4_input.txt"),
                        "5\n" +
                        "Иванова Мария 5 8 6 3\n" +
                        "Петров Сергей 9 9 5 7\n" +
                        "Сидоров Антон 9 9 5 7\n" +
                        "Смирнов Олег 4 5 6 7\n" +
                        "Кузнецов Денис 8 8 7 6\n");
            }
            if (!Files.exists(Path.of("task5_input.txt"))) {
                Files.writeString(Path.of("task5_input.txt"),
                        "Съешь же ещё этих мягких французских булок, да выпей чаю.\n");
            }
            if (!Files.exists(Path.of("task7_input.txt"))) {
                Files.writeString(Path.of("task7_input.txt"),
                        "Вася: 5\n" +
                        "петя: 3\n" +
                        "Аня: 5\n" +
                        "БезНомера:\n" +
                        "ДИМА: 3\n");
            }
        } catch (IOException e) {
            System.out.println("Предупреждение: не удалось создать тестовые файлы: " + e.getMessage());
        }
    }
}