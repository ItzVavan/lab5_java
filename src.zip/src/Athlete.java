import java.util.Arrays;

public class Athlete {
    private final String lastName;
    private final String firstName;
    private final int[] scores;
    private final int totalScore;

    public Athlete(String lastName, String firstName, int[] scores) {
        if (scores == null || scores.length != 4) {
            throw new IllegalArgumentException("Должно быть ровно 4 балла по видам спорта.");
        }
        for (int score : scores) {
            if (score < 0 || score > 10) {
                throw new IllegalArgumentException("Балл должен быть от 0 до 10.");
            }
        }
        this.lastName = lastName;
        this.firstName = firstName;
        this.scores = scores.clone();
        this.totalScore = Arrays.stream(scores).sum();
    }

    public String getFullName() {
        return lastName + " " + firstName;
    }

    public int getTotalScore() {
        return totalScore;
    }

    @Override
    public String toString() {
        return lastName + " " + firstName + " " + totalScore + " б. " + Arrays.toString(scores);
    }
}