public interface Fractionable {
    double getDoubleValue();
    void setNumerator(int numerator);
    void setDenominator(int denominator);
}