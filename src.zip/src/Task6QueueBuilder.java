import java.util.*;

public class Task6QueueBuilder {
    public static <T> Queue<T> buildMirroredQueue(List<T> list) {
        if (list == null) {
            throw new IllegalArgumentException("Входной список не может быть null.");
        }
        Queue<T> queue = new LinkedList<>(list);

        // Добавляем элементы в обратном порядке
        for (int i = list.size() - 1; i >= 0; i--) {
            queue.add(list.get(i));
        }

        return queue;
    }
}