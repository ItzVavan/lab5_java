import java.util.List;
import java.util.ListIterator;

public class Task3ListMerger {
    // Вставляет элементы упорядоченного списка l2 непосредственно в упорядоченный список l1
    public static <T extends Comparable<? super T>> void insertIntoSorted(List<T> l1, List<T> l2) {
        if (l1 == null || l2 == null) {
            throw new IllegalArgumentException("Списки не должны быть null.");
        }

        ListIterator<T> it1 = l1.listIterator();
        for (T item2 : l2) {
            boolean inserted = false;
            while (it1.hasNext()) {
                T item1 = it1.next();
                if (item2.compareTo(item1) <= 0) {
                    it1.previous();
                    it1.add(item2);
                    inserted = true;
                    break;
                }
            }
            if (!inserted) {
                it1.add(item2);
            }
        }
    }

    @Override
    public String toString() {
        return "Обработчик вставки упорядоченного списка L2 в L1";
    }
}