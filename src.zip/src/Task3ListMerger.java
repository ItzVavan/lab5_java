import java.util.ArrayList;
import java.util.List;

public class Task3ListMerger {
    public static <T extends Comparable<? super T>> List<T> mergeSorted(List<T> l1, List<T> l2) {
        if (l1 == null || l2 == null) {
            throw new IllegalArgumentException("Списки не должны быть null.");
        }
        List<T> result = new ArrayList<>();
        int i = 0, j = 0;

        while (i < l1.size() && j < l2.size()) {
            if (l1.get(i).compareTo(l2.get(j)) <= 0) {
                result.add(l1.get(i++));
            } else {
                result.add(l2.get(j++));
            }
        }
        while (i < l1.size()) {
            result.add(l1.get(i++));
        }
        while (j < l2.size()) {
            result.add(l2.get(j++));
        }

        return result;
    }
}