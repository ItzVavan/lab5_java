import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Task7StreamOps {

    // Задача 7.1: Обработка точек в стриме
    public static Polyline processPointsToPolyline(List<Point> points) {
        if (points == null) {
            throw new IllegalArgumentException("Список точек не может быть null.");
        }
        List<Point> processed = points.stream()
                .map(p -> new Point(p.getX(), Math.abs(p.getY())))
                .distinct()
                .sorted(Comparator.comparingDouble(Point::getX))
                .collect(Collectors.toList());

        return new Polyline(processed);
    }

    // Вспомогательный класс для задачи 7.2
    private static class Person {
        final String name;
        final Integer number;

        Person(String name, Integer number) {
            this.name = name;
            this.number = number;
        }
    }

    // Задача 7.2: Чтение из файла, приведение регистра и группировка
    public static Map<Integer, List<String>> groupPeopleByNumber(String filename) throws IOException {
        try (Stream<String> lines = Files.lines(Paths.get(filename))) {
            return lines
                    .map(String::trim)
                    .filter(line -> !line.isEmpty())
                    .map(line -> {
                        String[] parts = line.split(":", 2);
                        String rawName = parts[0].trim();
                        if (rawName.isEmpty()) return null;

                        String formattedName = rawName.substring(0, 1).toUpperCase()
                                + rawName.substring(1).toLowerCase();

                        Integer number = null;
                        if (parts.length > 1 && !parts[1].trim().isEmpty()) {
                            try {
                                number = Integer.parseInt(parts[1].trim());
                            } catch (NumberFormatException ignored) {
                            }
                        }
                        return new Person(formattedName, number);
                    })
                    .filter(p -> p != null && p.number != null)
                    .collect(Collectors.groupingBy(
                            p -> p.number,
                            Collectors.mapping(p -> p.name, Collectors.toList())
                    ));
        }
    }

    @Override
    public String toString() {
        return "Обработчик Stream API для Задания 7";
    }
}