import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Task4Processor {
    public static List<Athlete> findTopAthletes(String filename) throws IOException {
        List<Athlete> athletes = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String firstLine = reader.readLine();
            if (firstLine == null) {
                throw new IllegalArgumentException("Файл пуст.");
            }
            int n = Integer.parseInt(firstLine.trim());

            for (int i = 0; i < n; i++) {
                String line = reader.readLine();
                if (line == null) break;
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split("\\s+");
                if (parts.length != 6) {
                    throw new IllegalArgumentException("Неверный формат строки: " + line);
                }
                String lastName = parts[0];
                String firstName = parts[1];
                int[] scores = new int[4];
                for (int s = 0; s < 4; s++) {
                    scores[s] = Integer.parseInt(parts[2 + s]);
                }
                athletes.add(new Athlete(lastName, firstName, scores));
            }
        }

        // Группируем участников по баллам с помощью Map (TreeMap с обратным порядком ключей)
        Map<Integer, List<Athlete>> scoreMap = new TreeMap<>(Comparator.reverseOrder());
        for (Athlete a : athletes) {
            scoreMap.computeIfAbsent(a.getTotalScore(), k -> new ArrayList<>()).add(a);
        }

        // Выбираем участников, набравших 3 лучших результата (включая тех, кто разделил эти места)
        List<Athlete> topAthletes = new ArrayList<>();
        int countTiers = 0;
        for (Map.Entry<Integer, List<Athlete>> entry : scoreMap.entrySet()) {
            topAthletes.addAll(entry.getValue());
            countTiers++;
            if (countTiers == 3) {
                break;
            }
        }

        return topAthletes;
    }
}