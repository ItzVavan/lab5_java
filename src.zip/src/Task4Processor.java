import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Task4Processor {
    public static List<Athlete> findTopAthletes(String filename) throws IOException {
        List<Athlete> athletes = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String firstLine = reader.readLine();
            if (firstLine == null) {
                throw new IllegalArgumentException("Файл пуст.");
            }
            int n = Integer.parseInt(firstLine.trim());
            if (n < 1 || n > 100) {
                throw new IllegalArgumentException("Количество участников должно быть от 1 до 100.");
            }

            for (int i = 0; i < n; i++) {
                String line = reader.readLine();
                if (line == null) {
                    throw new IllegalArgumentException("Ожидалось строк: " + n + ", но файл закончился раньше.");
                }
                line = line.trim();
                if (line.isEmpty()) {
                    i--;
                    continue;
                }

                String[] parts = line.split("\\s+");
                if (parts.length != 6) {
                    throw new IllegalArgumentException("Неверный формат строки: " + line);
                }
                String lastName = parts[0];
                String firstName = parts[1];
                if (lastName.length() > 20 || firstName.length() > 15) {
                    throw new IllegalArgumentException("Превышена длина фамилии или имени: " + line);
                }

                int[] scores = new int[4];
                for (int s = 0; s < 4; s++) {
                    scores[s] = Integer.parseInt(parts[2 + s]);
                }
                athletes.add(new Athlete(lastName, firstName, scores));
            }
        }

        // Группируем участников по сумме баллов по убыванию
        Map<Integer, List<Athlete>> scoreMap = new TreeMap<>(Comparator.reverseOrder());
        for (Athlete a : athletes) {
            scoreMap.computeIfAbsent(a.getTotalScore(), k -> new ArrayList<>()).add(a);
        }

        // Выбираем 3 лучших участников (и всех, кто разделил с ними 3-е место)
        List<Athlete> topAthletes = new ArrayList<>();
        for (List<Athlete> group : scoreMap.values()) {
            topAthletes.addAll(group);
            if (topAthletes.size() >= 3) {
                break;
            }
        }

        return topAthletes;
    }

    @Override
    public String toString() {
        return "Обработчик результатов школьного многоборья";
    }
}