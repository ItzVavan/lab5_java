import java.util.Objects;

public class CachedFraction implements Fractionable {
    private final Fraction fraction;
    private Double cachedValue = null;

    public CachedFraction(Fraction fraction) {
        if (fraction == null) {
            throw new IllegalArgumentException("Объект дроби не может быть null.");
        }
        this.fraction = fraction;
    }

    public CachedFraction(int numerator, int denominator) {
        this(new Fraction(numerator, denominator));
    }

    @Override
    public double getDoubleValue() {
        if (cachedValue == null) {
            cachedValue = fraction.getDoubleValue();
            System.out.println("  [Кэш]: Значение рассчитано заново.");
        } else {
            System.out.println("  [Кэш]: Значение получено из кэша.");
        }
        return cachedValue;
    }

    @Override
    public void setNumerator(int numerator) {
        fraction.setNumerator(numerator);
        cachedValue = null;
    }

    @Override
    public void setDenominator(int denominator) {
        fraction.setDenominator(denominator);
        cachedValue = null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CachedFraction)) return false;
        CachedFraction that = (CachedFraction) o;
        return Objects.equals(fraction, that.fraction);
    }

    @Override
    public int hashCode() {
        return Objects.hash(fraction);
    }

    @Override
    public String toString() {
        return fraction.toString();
    }
}